<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Stefi
 * Date: 1/25/15
 * Time: 10:32 PM
 * To change this template use File | Settings | File Templates.
 */


$servername = "localhost";
$username = "root";
$password = "usbw";


try{
$db = new PDO('mysql:host=localhost;dbname=film;port=3307', 'root', 'usbw');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

    //echo "Connected successfully"; 
}
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
	
?> 
