<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Stefi
 * Date: 1/17/15
 * Time: 1:32 PM
 * To change this template use File | Settings | File Templates.
 */
//parametri za bazata

 
$servername = "localhost";
$username = "root";
$password = "usbw";

$db = new mysqli($servername, $username, $password);

if ($db == false)
    die('Unable to connect with server: ' . mysqli_error($db));
if ( mysqli_select_db($db, "film") === false )
    die("Unable to select database");
//mysqli_set_charset($db, 'utf8');

$db->set_charset("utf8");

 
 
?>



