-- phpMyAdmin SQL Dump
-- version 4.0.4.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 22, 2017 at 01:26 AM
-- Server version: 5.6.13
-- PHP Version: 5.4.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `film`
--
CREATE DATABASE IF NOT EXISTS `film` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `film`;

-- --------------------------------------------------------

--
-- Table structure for table `filmovi`
--

CREATE TABLE IF NOT EXISTS `filmovi` (
  `film_id` int(10) NOT NULL AUTO_INCREMENT,
  `ime` varchar(255) NOT NULL,
  `slika` varchar(255) NOT NULL,
  `kategorija_id` int(10) NOT NULL,
  PRIMARY KEY (`film_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=146 ;

--
-- Dumping data for table `filmovi`
--

INSERT INTO `filmovi` (`film_id`, `ime`, `slika`, `kategorija_id`) VALUES
(1, 'Parker 2013', 'images/parker.jpg', 1),
(2, '2 Guns 2013', 'images/2guns.jpg', 1),
(3, 'World War Z 2013', 'images/worldwarz.jpg', 1),
(4, 'The Expendables 3 2013', 'images/theexpendables3.jpg', 1),
(5, 'Predestination 2014', 'images/predestination.jpg', 1),
(6, 'Guardians of the Galaxy 2014', 'images/guardiansofthegalaxy.jpg', 1),
(7, 'Big Eyes 2014 ', 'images/bigeyes.jpg', 2),
(8, 'Blood of Redemption 2013', 'images/bloodofredemption.jpg', 2),
(9, 'The Godfather 1972', 'images/godfather.jpg', 2),
(10, 'No Country for Old Men 2007', 'images/nocountryforoldmen.jpg', 2),
(11, 'PK 2014', 'images/pk.jpg', 2),
(12, 'Inherent Vice 2014', 'images/inherentvice.jpg', 2),
(13, 'Dumb and Dumber To 2014', 'images/dumbanddumberto.jpg', 3),
(14, 'The Wolf of Wall Street 2014', 'images/thewolfofwallstreet.jpg', 3),
(15, 'Walk of Shame 2014', 'images/walkofshame.jpg', 3),
(16, '22 Jump Street 2014', 'images/22jumpstreet.jpg', 3),
(17, 'Into the Woods 2014', 'images/intothewoods.jpg', 3),
(18, 'Kingsman: The Secret Service 2014', 'images/thesecretservice.jpg', 3),
(19, 'A Good Marriage 2014', 'images/agoodmarriage.jpg', 4),
(20, 'The Killer Inside Me 2010', 'images/thekillerinsideme.jpg', 4),
(21, 'Another me 2014', 'images/anotherme.jpg', 4),
(22, 'Before I go to sleep 2014', 'images/beforeigotosleep.jpg', 4),
(23, 'Enemies Closer 2014', 'images/enemiescloser.jpg', 4),
(24, 'Frankenstein 2014', 'images/frankenstein.jpg', 4),
(25, ' At the Devil’s Door  2014', 'images/atthedevilsdoor.jpg', 5),
(26, 'Proxy 2013', 'images/proxy.jpg', 5),
(27, 'Torment 2013 ', 'images/torment.jpg', 5),
(28, 'See No Evil II 2014', 'images/seenoevil2.jpg', 5),
(29, 'What We Do in the Shadows  2014', 'images/whatwedointheshadows.jpg', 5),
(30, 'The Conjuring 2013', 'images/theconjuring.jpg', 5),
(31, 'Fury 2014', 'images/fury.jpg', 1),
(32, 'Snowpierces 2013', 'images/snowpierces.jpg', 1),
(33, 'Laggies 2014', 'images/laggies.jpg', 3),
(34, 'Don Jon 2013', 'images/donjon.jpg', 3),
(35, 'About Time 2013', 'images/abouttime.jpg', 2),
(36, 'The best offer  2013', 'images/thebbestoffer.jpg', 2),
(37, 'Gravity  2013', 'images/gravity.jpg', 4),
(38, 'Coherence  2013', 'images/coherence.jpg', 4),
(39, 'Afflicted 2013', 'images/afflicted.jpg', 5),
(40, 'The Sacramen 2013', 'images/thesacramen.jpg', 5),
(41, 'Son of the Gun 2014', 'images/3daystokill.jpg', 1),
(42, 'The Maze Runner 2014', 'images/themazerunner.jpg', 1),
(43, 'The Equalizer 2014', 'images/theequalizer.jpg', 1),
(44, 'Dracula Untold 2014', 'images/draculauntold.jpg', 1),
(45, 'American Heist 2014', 'images/americanheist.jpg', 1),
(46, 'Divergent 2014', 'images/divergent.jpg', 1),
(47, 'Maleficent 2014', 'images/maleficent.jpg', 1),
(48, 'Redirected 2014', 'images/redirected.jpg', 1),
(49, 'Noah 2014', 'images/noah.jpg', 1),
(50, 'Godzilla 2014', 'images/godzilla.jpg', 1),
(51, 'Wolves 2014', 'images/wolves.jpg', 1),
(52, 'Hercules 2014', 'images/hercules.jpg', 1),
(53, 'The Guest 2014', 'images/theguest.jpg', 1),
(54, 'Outcast  2014', 'images/outcast.jpg', 1),
(55, 'Non-Stop  2014', 'images/non-stop.jpg', 1),
(56, 'Left Behind  2014', 'images/leftbehind.jpg', 1),
(57, 'Convict  2014', 'images/convict.jpg', 1),
(58, 'Point Break  1991', 'images/pointbreak.jpg', 1),
(59, 'RoboCop  2014', 'images/robocop.jpg', 1),
(60, 'Fast & Furious 6 2013', 'images/fast&furious6.jpg', 1),
(61, '3 Days to Kill 2014', 'images/3daystokill.jpg', 1),
(62, 'Ride Along 2014', 'images/ridealong.jpg', 1),
(63, 'Desert Dancer 2014 ', 'images/desertdancer.jpg', 2),
(64, 'God Help the Girl 2014 ', 'images/godhelpthegirl.jpg', 2),
(65, 'The Longest Week 2014', 'images/thelongestweek.jpg', 2),
(66, 'Kite 2014', 'images/kite.jpg', 2),
(67, 'Catch Hell 2014', 'images/catchhell.jpg', 2),
(68, 'The Lookalike 2014 ', 'images/thelookalike.jpg', 4),
(69, 'Into the Storm 2014', 'images/intothestorm.jpg', 4),
(70, 'The Houses October Built 2014', 'images/thehousesoctoberbuilt.jpg', 4),
(71, 'The Prince 2014 ', 'images/theprince.jpg', 4),
(72, 'John Wick 2014 ', 'images/johnwick.jpg', 4),
(73, 'The November Man 2014', 'images/thenovemberman.jpg', 4),
(74, 'The Two Faces of January 2014', 'images/thetwofacesofjanuary.jpg', 4),
(75, 'Stonehearst Asylum 2014', 'images/stonehearstasylum.jpg', 4),
(76, 'The Signal 2014', 'images/thesignal.jpg', 4),
(77, 'Jinn 2014', 'images/jinn.jpg', 4),
(78, 'Jersey Boys 2014  ', 'images/jerseyboys.jpg', 2),
(79, 'If I Stay 2014 ', 'images/ifistay.jpg', 2),
(80, 'The Giver 2014 ', 'images/thegiver.jpg', 2),
(81, 'Heaven Is for Real 2014 ', 'images/heavenisforreal.jpg', 2),
(82, 'The Retrieval 2014 ', 'images/theretrieval.jpg', 2),
(84, 'Two Night Stand 2014', 'images/twonightstand.jpg', 3),
(85, 'St. Vincent 2014', 'images/stvincent.jpg', 3),
(86, 'Sex Tape 2014', 'images/sextape.jpg', 3),
(87, 'Tammy 2014', 'images/tammy.jpg', 3),
(88, 'Chef 2014', 'images/chef.jpg', 3),
(89, 'Pride 2014', 'images/pride.jpg', 3),
(90, 'Tangled 2010', 'images/tangled.jpg', 3),
(91, 'What If 2013', 'images/whatif.jpg', 3),
(92, 'This Is The End 2013', 'images/thisistheend.jpg', 3),
(94, 'Despicable Me 2010', 'images/despicableme.jpg', 3),
(95, 'Home Alone 1990', 'images/homealone.jpg', 3),
(96, 'Are You Here 2014', 'images/areyouhere.jpg', 3),
(97, 'The Mule 2014', 'images/themule.jpg', 3),
(98, 'The Internship 2013', 'images/theinternship.jpg', 3),
(99, 'Vampire Academy 2014', 'images/vampireacademy.jpg', 3),
(100, 'The Heat 2013', 'images/theheat.jpg', 3),
(101, 'Bad Words 2013', 'images/badwords.jpg', 3),
(102, 'Frank  2014', 'images/frank.jpg', 3),
(103, 'Veronica Mars 2014', 'images/veronicamars.jpg', 3),
(104, 'Date and Switch 2014', 'images/dateandswitch.jpg', 3),
(105, 'Filth  2013', 'images/filth.jpg', 3),
(106, 'Admission 2013', 'images/admission.jpg', 3),
(124, 'Аnnabelle 2014', 'images/annabelle.jpg', 5),
(125, 'Ouija 2014', 'images/ouija.jpg', 5),
(126, 'The Purge: Anarchy 2014', 'images/thepurgeanarchy.jpg', 5),
(127, 'The Babadook 2014', 'images/thebabadook.jpg', 5),
(128, 'Julia 2014', 'images/julia.jpg', 5),
(129, 'Only Lovers Left Alive 2013', 'images/onlyloversleftalive.jpg', 5),
(130, 'Animal 2014', 'images/animal.jpg', 5),
(131, 'Oculus 2014', 'images/oculus.jpg', 5),
(132, 'The Woman in Black 2012', 'images/thewomaninblack.jpg', 5),
(133, 'As Above, So Below 2014', 'images/asabovesobelow.jpg', 5),
(134, 'The Shining1980', 'images/theshining.jpg', 5),
(135, 'Housebound 2014', 'images/housebound.jpg', 5),
(136, 'Banshee Chapter 2014', 'images/bansheechapter.jpg', 5),
(137, 'Lemon Tree Passage 2014', 'images/lemontreepassage.jpg', 5),
(138, 'Sinister 2012', 'images/sinister.jpg', 5),
(139, 'Alien Abduction 2014', 'images/alienabduction.jpg', 5),
(140, 'Mama 2013', 'images/mama.jpg', 5),
(141, '13 Sins 2014', 'images/13sins.jpg', 5),
(142, 'The Thing1982', 'images/thething.jpg', 5),
(143, '1408 2007', 'images/1408.jpg', 5),
(144, 'Dawn of the Dead 2004', 'images/dawnofthedead.jpg', 5),
(145, 'Friday the 13th 2009', 'images/fridaythe13th.jpg', 5);

-- --------------------------------------------------------

--
-- Table structure for table `kategorija`
--

CREATE TABLE IF NOT EXISTS `kategorija` (
  `kategorija_id` int(10) NOT NULL AUTO_INCREMENT,
  `kategorija_ime` varchar(255) NOT NULL,
  PRIMARY KEY (`kategorija_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `kategorija`
--

INSERT INTO `kategorija` (`kategorija_id`, `kategorija_ime`) VALUES
(1, 'akcija'),
(2, 'drama'),
(3, 'komedija'),
(4, 'triler'),
(5, 'horor');

-- --------------------------------------------------------

--
-- Table structure for table `komentari`
--

CREATE TABLE IF NOT EXISTS `komentari` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sodrzina` varchar(255) NOT NULL,
  `date` varchar(50) DEFAULT NULL,
  `film_id` int(10) NOT NULL,
  `korisnik_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=157 ;

--
-- Dumping data for table `komentari`
--

INSERT INTO `komentari` (`id`, `sodrzina`, `date`, `film_id`, `korisnik_id`) VALUES
(142, 'Super e filmot :))', '2015-02-11 21:57:35', 1, 13),
(143, 'Filmot e mnogu mnogu smesen, mora da go gledate ;)', '2015-02-11 21:58:32', 13, 13),
(144, 'Odlicen e , pozz', '2015-02-11 22:05:29', 12, 13),
(145, 'ne e los :)', '2015-02-11 22:06:06', 42, 13),
(146, 'najdobarrr :)))))))', '2015-02-11 22:06:39', 16, 13),
(147, 'najdobar glumec :D', '2015-02-11 22:06:59', 55, 13),
(148, 'top film :))', '2015-02-11 22:13:47', 48, 18),
(149, 'da, go gledav filmot, mnogu e dobar, a ima i drug del mora da go gledate. pozdraaav :D', '2015-02-11 22:14:46', 13, 18),
(150, 'strasnoooo ://', '2015-02-11 22:15:19', 30, 18),
(151, 'dobar e ', '2015-02-11 22:16:02', 22, 18),
(152, 'super film ', '2015-02-11 22:16:21', 5, 18),
(153, 'zalnicko :/', '2015-02-11 22:17:47', 42, 18),
(154, 'odlicen film, bravos :D', '2015-02-11 22:18:38', 16, 18),
(155, 'Super e filmot', '2015-02-12 12:19:55', 97, 19),
(156, 'film vreden za gledanje :)) ', '2015-02-12 14:40:53', 3, 13);

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

CREATE TABLE IF NOT EXISTS `korisnici` (
  `kluc` int(10) NOT NULL AUTO_INCREMENT,
  `ime` varchar(30) NOT NULL,
  `prezime` varchar(60) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `lozinka` varchar(100) NOT NULL,
  PRIMARY KEY (`kluc`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`kluc`, `ime`, `prezime`, `username`, `email`, `lozinka`) VALUES
(13, 'Stefanija', 'Veselinova', 'Stefanija', 'stefi_veselinova@hotmail.com', 'ad363a93848bc486036e6b57d00415cdd2fe1b97'),
(16, 'Stole', 'Krstov', 'Stole', 'stole@hotmail.com', 'ad363a93848bc486036e6b57d00415cdd2fe1b97'),
(17, 'Kristijan', 'Veselinov', 'Kristijan', 'kristijan@hotmail.com', 'ad363a93848bc486036e6b57d00415cdd2fe1b97');

-- --------------------------------------------------------

--
-- Table structure for table `sekojfilm`
--

CREATE TABLE IF NOT EXISTS `sekojfilm` (
  `detali_id` int(10) NOT NULL AUTO_INCREMENT,
  `kategorija` varchar(10) NOT NULL,
  `rezija` varchar(30) NOT NULL,
  `ocena` float NOT NULL,
  `akteri` varchar(255) NOT NULL,
  `drzava` varchar(255) NOT NULL,
  `godina` int(5) NOT NULL,
  `vremetraenje` int(5) NOT NULL,
  `sodrzina` varchar(500) NOT NULL,
  `film_id` int(10) NOT NULL,
  `official_trailer` varchar(100) NOT NULL,
  PRIMARY KEY (`detali_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=146 ;

--
-- Dumping data for table `sekojfilm`
--

INSERT INTO `sekojfilm` (`detali_id`, `kategorija`, `rezija`, `ocena`, `akteri`, `drzava`, `godina`, `vremetraenje`, `sodrzina`, `film_id`, `official_trailer`) VALUES
(1, 'Акција  ', 'Taylor Hackford ', 6.2, 'Jason Statham, Jennifer Lopez, Michael Chiklis, Emma Booth, Wendell Pierce, Patti LuPone', 'United States', 2013, 118, 'Еден ветеран-криминалец со бескомпромисен код на честа бара одмазда против жестоката банда која го измами Паркер.  Паркер е еден од најсмелите, безмилосни крадци во овој бизнис, тој е експерт во планирањето и спроведувањето наизглед невозможни грабежи. Ед', 1, 'https://www.youtube.com/watch?v=Pa9LS35AudM'),
(2, 'Акција', 'Baltasar Kormákur', 6.8, 'Denzel Washington, Mark Wahlberg, Paula Patton, Edward James Olmos, Bill Paxton, Evie Thompson', 'United States', 2013, 109, 'Агент од американската служба за наркотици и поморски офицер од разузнавачката служба се наоѓаат во бегство, после неуспешниот обид да се инфилтрираат во картел на дрога. Додека бегале, тие ја откриле тајната на нивната алијанса: Ниту еден од нив не знаел', 2, 'https://www.youtube.com/watch?v=AK6EbfdnTHg'),
(3, 'Акција', 'Marc Forster', 7, 'Brad Pitt, Mireille Enos, Daniella Kertesz, James Badge Dale, James Badge Dale', 'United States', 2013, 116, 'Вработениот во Обединетите Нации Гери Лејн го преминува целиот свет во трка со времето за да ја запре зомби пандемијата која што ги соборува војските и владите и се заканува да го уништи човештвото.', 3, 'https://www.youtube.com/watch?v=4EC7P5WdUko'),
(4, 'Акција', 'Patrick Hughes', 6.2, 'Sylvester Stallone, Jason Statham, Jet Li, Arnold Schwarzenegger, Mel Gibson', 'United States', 2014, 127, 'Во третиот дел долгоочекуваните главни оперативци ќе тргнат во потрага со своите наследници. Сметаат дека дошло време да функционираат побрзо и посилно, бидејќи се впуштаат во задача која воопшто не е лесна за извршување.', 4, 'https://www.youtube.com/watch?v=OSETH2a2054'),
(5, 'Акција', 'Peter Spierig, Michael Spierig', 7.5, 'Ethan Hawke, Sarah Snook, Noah Taylor, Christopher Sommers, Paul Moder, Cate Wolfe', 'Australia', 2014, 97, 'Го следиме животот на временскиот агент Итан Хоукс кој оди на серија сложени патувања низ времето со цел да ги спречи идните убијци пред да почнат со своите злочини. На својата последна задача агентот мора да го спречи криминалецот кој постојано успева да', 5, 'https://www.youtube.com/watch?v=-FcK_UiVV40'),
(6, 'Акција', 'James Gunn', 8.2, 'Chris Pratt, Zoe Saldana, Dave Bautista, Vin Diesel, Bradley Cooper, Lee Pace, Michael Rooker, Karen', 'United States', 2014, 122, 'Една група на интергалактички криминалци се принудени да работат заедно со цел да се запре фанатичен воин од преземање на контролата над целата вселена.', 6, 'https://www.youtube.com/watch?v=b3isCLVghoI'),
(7, 'Драма', 'Tim Burton', 7, 'Amy Adams, Christoph Waltz, Krysten Ritter, Jason Schwartzman, Elisabetta Fantone, Terence Stamp', 'United States, Canada', 2014, 106, 'Ова е драма за  сликарот Маргарет Кин и нејзиниот феноменален успех во 1950 година. Потоа има пресвртница во животот, т.е и се појавуваат тешки проблеми со нејзиниот сопруг.', 7, 'https://www.youtube.com/watch?v=2xD9uTlh5hI'),
(8, 'Драма', 'Giorgio Serafini, Shawn Sourgo', 4.5, 'Dolph Lundgren, Billy Zane, Gianni Capaldi, Vinnie Jones, Robert Davi, MassiFurlan, LaDon Drummond ', 'United States', 2013, 85, 'Квин Форте имаше се: моќ, пари, брат кој го идолизираше, жена која го сакаше, но имаше и непријатели. Во текот на една ноќ, тој изгуби се. Предаден од некој во неговиот круг, па така тој е уапсен. Неговиот татко, патријарх на кривичната империја е убиец и', 8, 'https://www.youtube.com/watch?v=82XwtyTU_1k'),
(9, 'Драма', 'Francis Ford Coppola', 9.2, 'Marlon Brando, Al Pacino, James Caan, Sterling Hayden, John Marley, Robert Duvall, Diane Keaton, Richard Conte', 'United States', 1972, 175, 'Најшироко се смета како еден од најдобрите филмови на сите времиња. Oваа драма e фокусиранa на моќни Италијанско-Американска криминална фамилија на Дон Вито Корлеоне. Кога најмладиот син на Дон Вито Корлеоне, Мајкл не по своја волја се приклучува на мафиј', 9, 'https://www.youtube.com/watch?v=5DO-nDW43Ik'),
(10, 'Драма', 'Ethan Coen, Joel Coen', 8.1, 'Tommy Lee Jones, Javier Bardem, Josh Brolin, Kelly Macdonald, Garret Dillahunt, Tess Harper, Stephan Root', 'United States', 2007, 122, 'Доаѓајќи од лов, Левин Мос го пронаоѓа хоророт од последиците со договорот со дрога. Иако тој не знае што да прави, не може да издржи а да не ги земе парите. Поради тоа почнува да го прогонува безмилосен убиец.Насилство и хаос настанува бидејќи станува зб', 10, 'https://www.youtube.com/watch?v=38A__WT3-o0'),
(11, 'Драма', 'Rajkumar Hirani', 8.7, 'Aamir Khan, Anushka Sharma, Sushant Singh Rajput, Boman Irani, Saurabh Shukla, Sanjay Dutt', 'India', 2014, 153, 'Странец во градот поставува прашања што никој претходно не ги прашал. Познат само по неговите иницијали ПК. Поради поставувањето на невини прашања и неговата детска љубопитност ќе го доведат до едно незаборавно патување на љубов, смеа и допуштање.', 11, 'https://www.youtube.com/watch?v=82ZEDGPCkT8'),
(12, 'Драма', 'Paul Thomas Anderson', 7.3, 'Joaquin Phoenix, Josh Brolin, Owen Wilson, Katherine Waterston, Reese Witherspoon, Benicio del Toro,', 'United States', 2014, 148, 'Во Калиформија заедницата за плажа, приватниот детектив Лери Спортељо има тенденција да работи на своите случаи низ чадот на маглата на марихуаната. Еден ден, Шаста поранешна негова љубовница, доаѓа од никаде да се изјасни за помош од Лери. И се чини дека', 12, 'https://www.youtube.com/watch?v=wZfs22E7JmI'),
(13, 'Комедија', 'Bobby Farrelly, Peter Farrelly', 6.2, 'Jim Carrey, Jeff Daniels, Rachel Melvin, Rob Riggle, Laurie Holden, Patricia French, Don Lake, Kathleen Turner', 'United States', 2014, 109, 'Незаборавните Лојд и Хари поминати веќе 20 години од својата прва авантура се впуштаат во уште полуда и незаборавна која ќе им ги смени животите. Тие одат на патување за да се најдат ново откриените ќерка на Хари. Хари беше даден на посвојување.', 13, 'https://www.youtube.com/watch?v=bIqvQFqPavA'),
(14, 'Комедија', 'Martin Scorsese', 8.3, 'Leonardo DiCaprio, Margot Robbie, Jonah Hill, Margot Robbie, Cristin Milioti, Kyle Chandler, Joanna Lumley', 'United States', 2013, 180, 'Врз основа на вистинска приказна за Јордан Белфорд, од неговиот подем на богатите акции до неговиот пад, вклучувајќи криминал, корупцијата и федералната влада. Филм кој ни ги претставува удобностите живеејќи на висока нога.', 14, 'https://www.youtube.com/watch?v=iszwuX1AK6A'),
(15, 'Комедија', 'Steven Brill', 6, 'Elizabeth Banks, James Marsden, Gillian Jacobs, Sarah Wright, Ethan Suplee, Bill Burr, Ken Davitian, Eric Etebari', 'United States', 2014, 95, 'Нејзиниот сон е да постане  позната новинарка која ги води вестите на познатите телевизии. Но една ноќ таа останува на цедило во центарот на Лос Анџелес т.е останува без телефон, автомобил, проект и пари. Но најбитното е тоа што за само 8 часа таа треба д', 15, 'https://www.youtube.com/watch?v=hTDg9hN6uNQ'),
(16, 'Комедија', 'Phil Lord, Christopher Miller', 7.2, 'Channing Tatum, Jillian Bell, Jonah Hill, Ice Cube, Amber Stevens, Joe Chrest, Nick Offerman, Jimmy Tatro', 'United States', 2014, 112, 'Двајцата другари уште од средно повторно се наоѓаат и се впуштаат во неодолива авантура. Сепак најголемите промени се наоѓаат во продавницата на Шмит и Јенко. Тие откриваат длабоки тајни кои се присутни во локалниот колеџ.', 16, 'https://www.youtube.com/watch?v=qP755JkDxyM'),
(17, 'Комедија', 'Rob Marshall', 6.6, 'Meryl Streep, Emily Blunt, James Corden, Anna Kendrick, Chris Pine, Tracey Ullman, Christine Baransk', 'United States', 2014, 124, 'Како резултат на клетва од некогаш убавата вештерка (Мерил Стрип), со прекар (Џејмс Корден) и неговата сопруга (Емили Блунт) се деца. Три дена пред да се појави плавата месечина, тие се впуштаат во шумата за да најдат состојки кои ќе вратат убавината на в', 17, 'https://www.youtube.com/watch?v=7pjy5MK1X70'),
(18, 'Комедија', 'Matthew Vaughn', 8.5, 'Colin Firth, Samuel L. Jackson, Mark Strong, Taron Egerton, Michael Caine, NeveGachev, Tom Prior', 'United Kingdom', 2014, 129, 'Избрани се млади мажи и жени да станат витези на новото време и нивната акција во рамки на тајната служба Кингсман се одвива во максимална дискреција. Но, за да се постигнат овие ласкави титули, потенцијалните агенти мора да се подложат не само на специја', 18, 'https://www.youtube.com/watch?v=kl8F-8tR8to'),
(19, 'Трилер', 'Peter Askin', 5.1, 'Joan Allen, Anthony LaPaglia, Kristen Connolly, Stephen Lang, Cara Buono, Will Rogers, Robert Hogan', 'United States', 2014, 102, '"Добриот брак" е приказна на Стивен Кинг. Овде станува збор за една жена која открива дека нејзиниот сопруг крие мрачна убиствена тајна. И таа мора да се обиде да го запре тоа како знае и умее. Истоимената кратка приказна е објавена во колекцијата "Целосн', 19, 'https://www.youtube.com/watch?v=_cKNdMdjiW8'),
(20, 'Трилер', 'Michael Winterbottom', 6.2, 'Casey Affleck, Kate Hudson, Jessica Alba, Bill Pullman, Matthew Maher, Ned Beatty, Elias Koteas, Simon Baker', 'United States', 2010, 109, 'Западниот Тексас е заменик шериф кој полека се демаскира како психотичен убиец. Станува збор за една љубовна врска која начисто ќе ве збуни бидејќи нивните цели во животот се сосема различни.', 20, 'https://www.youtube.com/watch?v=BO9lzxOai10'),
(21, 'Трилер', 'Isabel Coixet', 4.8, 'Claire Forlani, Sophie Turner, Jonathan Rhys Meyers, IvanaBaquero, Leonor Watling, Melanie Walters', 'United Kingdom, Spain', 2014, 86, 'Животот на Феј полека се открива. Доста мистериозен филм кој ќе ве заинтригира се повеќе и повеќе карактерот и животот на Феј.Таа постојано е надгледувана за да и го украдат нејзиниот идентитет и живот.', 21, 'https://www.youtube.com/watch?v=VkyBzfIwnNU'),
(22, 'Трилер', 'Rowan Joffe', 6.2, 'Nicole Kidman, Mark Strong, Colin Firth, Anne-Marie Duff, Ben Cromton, Adam Levy, Gabriel Strong', 'United Kingdom, France, Sweden', 2014, 90, 'Една жена живее многу трауматичен живот т.е не толку многу за неа како за луѓето околу неа. Нејзиниот живот навидум е нормален, но длабоко се крие една несреќа која засекогаш и го сменила животот. Таа се буди секој ден, несеќавајќи се на ништо од претходн', 22, 'https://www.youtube.com/watch?v=tQdnOYpyBCo'),
(23, 'Трилер', 'Peter Hyams', 5.1, 'Jean-Claude Van Damme, Tom Everett Scott, Orlando Jones, Kristopher Van Varenberg, Linzey Cocker, Za', 'United States, Canad', 2013, 85, 'Длабоко во шумата на американско-канадската граница, двајца непријатели мора да работат заедно. Иако воопшто не се поднесуваат тие мора да соработуваат за да избегат безмилосен картел на дрога. Голема трагедија им се случува кога не можат да ја најдат дро', 23, 'https://www.youtube.com/watch?v=WHrYuULPUuc'),
(24, 'Трилер', 'Stuart Beattie', 5.2, 'Aaron Eckhart, Bill Nighy, Yvonne Strahovski, Miranda Otto, Socratis Otto, Jai Courtney, Kevin Grevi', 'United States, Austr', 2014, 92, 'После два века д-р Франкенштајн го составува и реанимира неговотo суштество. Адам пак поточно Арон Екхарт е се уште жив. Тој се вовлекува во војна помеѓу две бесмртни трки: традиционалните заштитници на човештвото и злобните демони. Откако Адам е ниту чов', 24, 'https://www.youtube.com/watch?v=NXc5epxOH_c'),
(25, 'Хорор', 'Nicholas McCarthy', 4.8, 'Catalina Sandino Moreno, Naya Rivera, Ashley Rickards, Mark Steger, Ava Acres, Assaf Cohen, Nick Eversman', 'United States', 2014, 91, 'Кога младите и амбициозни агенти за недвижности Ли е побарано да ја продаде куќата со кариран минатото, таа преминува патеки со нарушено девојка за кои верува дека е бегство ќерка на двојката продажба на имотот. Кога Ли се обидува да интервенира и да им п', 25, 'https://www.youtube.com/watch?v=MzH7LpTPU9E'),
(26, 'Хорор', 'Zack Parker', 5.6, 'Joe Swanberg, Kristina Klebe, Alexa Havins, Brittany Wagner, Faust Checho, Kitse Duncan, Faust Checho', 'United States', 2013, 120, 'Во овој филм станува збор за животот на три фамилии кои мора да го живеат со мрачната трагедија. Ни е претставен нивниот живот и нивните навики. Како можат да се справат родителите по загуба на своето дете. Тоа е главната тематика на овој филм кој ги повр', 26, 'https://www.youtube.com/watch?v=-chvqkdo5wU'),
(27, 'Хорор  ', 'Jordan Barker', 4.8, 'Katharine Isabelle, Robin Dunne, Peter DaCunha, Amy Forsyth, InessaFrantowski, Noah Danby', 'Canada', 2013, 82, 'Брачната двојка Кори и Сара Морган го земаат 7-годишниот син Лиам во земјата за некои потребни семејства. Кога таа се појавува, Лиам им бега, психолошката неизвеснот станува директно ужасна. Сара и Кори мораат сега да се соочат со садистичкиот култ како с', 27, 'https://www.youtube.com/watch?v=abbegmVqDFs'),
(28, 'Хорор  ', 'Jen Soska, Sylvia Soska', 4, 'Glenn Jacobs, Danielle Harris, Katharine Isabelle, Lee Majdoub, Greyston Holt, Reese Alexander', 'United States', 2013, 90, 'Група пријатели плаќаат за ноќни посети во градската мртовечница за да ја изненадат Ејми на нејзиниот роденден. Но, изненадувањето е за нив, кога едноок труп брутален психопат Џејков неочекувано се издига од студена подрумска плоча. Нивната забава брзо се', 28, 'https://www.youtube.com/watch?v=pV5EqlKMOvM'),
(29, 'Хорор', 'Jemaine Clement, Taika Waititi', 7.7, 'Taika Waititi, Jemaine Clement, Rhys Darby, Jonathan Brugh, Cori Gonzalez-Macuer, Stu Rutherford', 'New Zealand', 2014, 85, 'Ваквите жанрови на филмови најчесто се бават со вампири, па овој филм не е исклучок. Станува збор за група од вампири кои постојано се караат околу валканите садови, дискутираат за мода и одат на забави. Кога тие ќе го претворат Ник во вампир, тогаш наста', 29, 'https://www.youtube.com/watch?v=9DW71_lN510'),
(30, 'Хорор', 'James Wan', 7.5, 'Vera Farmiga, Patrick Wilson, Lili Taylor, Ron Livingston, Јоеѕ King, Shannon Kook,Shanley Caswell ', 'United States', 2013, 112, 'Паранормал истражувачите Ед и Лорен Ворен работат за да помогнат на семејство. Преплашеното семејство чувствува како да не се сами во својата куќа. По долго измачување ги повикуваат истражувачите да го решат нивниот проблем во нивната куќа.', 30, 'https://www.youtube.com/watch?v=_FCaLiZtu9s'),
(31, 'Акција', 'David Ayer', 7.7, 'Brad Pitt, Shia LaBeof, LoganLerman, Jim Parrack, Xavier Samuel, AnamariaMarinca, Jon Bernthal, Scott Eastwood', 'United States, Kina, United Kingdom', 2014, 135, 'Филмот е за кобната 1945 година во месец Април. Станува збор за многу храбри војници. На чело со наредникот на армијата Wardaddy и неговиот најбитен пет-член екипаж се на мисија позади непријателските линии. Wardaddy и неговите луѓе се соочуваат со огромни шанси во нивната херојска битка се со цел да се удри во срцето на нацистичка Германија.', 31, 'https://www.youtube.com/watch?v=DNHuK1rteF4'),
(32, 'Акција', 'Joon-ho Bong', 7, 'Chris Evans, Jamie Bell, TildaSwinton, John Hurt, Octavia Spencer, Jamie Bell, TildaSwinton, Alison Pill', 'South Korea, Czech Republic', 2013, 126, 'Настануваат проблеми со климата на планетата Земја, но големите научници го знаат предвреме тоа но не го излагаат на виделина. Сите човечки животи кои останаа т.е целиот свет на планетат Земја измуре, само преживејаа оние мал број на луѓе кои се качија на Snowpiercer.', 32, 'https://www.youtube.com/watch?v=fyWfZ9866DE'),
(33, 'Комедија', 'Lynn Shelton', 6.6, 'Keiar Knightley, Chloe, Grace Moretz, Sam Rockwell, Eric Riedmann, Jeff Garlin, Sara Coates, Daniel Zovatto', 'United States', 2014, 100, 'Меган паничи кога нејзиното момче ќе и предложи да избегаат за една недела. Таа не знае како да постапи и се крие кај нејзиниот нов пријател Аника.', 33, 'https://www.youtube.com/watch?v=WQEYmmErpjg'),
(34, 'Комедија', 'Joseph Gordon-Levitt', 6.7, 'Joseph Gordon-Levitt, Scarlett Johansson, Julianne Morore, Brie Larson, GlenneHeadly, Rob Brown  ', 'United States', 2013, 90, 'Нормален човек кој живее во Њу Џерси посветен на семејството, работата, пријателите. Но гледајќи подолго време на интернет, кај него се развива некое ново чувство за живот, а тоа е пронаоѓајќи интимност и вистинска љубов.', 34, 'https://www.youtube.com/watch?v=bcGO_oAahV8'),
(35, 'Драма', 'Riechard Curtis', 7.8, 'Domhnall Gleeson, Rachel McAdams, Bill Nighy, Lindsay Duncan, Lydia Wilson, Joshua McGuire, Margot Robbie   ', 'United Kingdom', 2013, 123, 'На својата 21 година, Том открива една тајна за себе која не ја знаел до тогаш. Тој може да патува низ времето и да го менува својот живот. Тој тргнува во мисија за добра девојка кое навидум му изгледа лесно и едноставно, но работите ќе се искомплицираат.', 35, 'https://www.youtube.com/watch?v=T7A810duHvw'),
(36, 'Драма', 'Giuseppe Tornatre ', 7.8, 'Geoffrey Rush, Jim Sturgess, Sylvia Hoeks, Sylvia Hoeks, Gen Seto, KirunaStamell, Philip Jacksn, Maximilian Dirr ', 'Italy', 2013, 131, 'Богат акционер има се. Тој станува зависник од една наследничка која собира се што е поврзано со ликовна уметност.', 36, 'https://www.youtube.com/watch?v=WCfXq3nFDUM'),
(37, 'Трилер', 'Alfonso Cuaron', 8, 'Sandra Bullock, George Clooney, Ed Harris, Phaldut Sharma, Basher Savage, OrtoIgmatiussen ', 'United Kingdom, United States', 2013, 91, 'Медицински инженер и астронаут работат заедно за подобрување на нештата, но настануваат големи проблеми кои ќе остават белег засекогаш кај нив.', 37, 'https://www.youtube.com/watch?v=doLizp4PJmc'),
(38, 'Трилер', 'James Ward Byrkit', 7.1, 'Emily Baldoni, Maury Streling, Nicholas Brendon, Alex Manugian, Lauren Maher, Lorene Scafaria ', 'United Kingdom, United States', 2013, 89, 'Чудни работи почнуваат да се случуваат кога група од пријатели се собираат на една вечера. Во таа најобична вечер прблемите настануваат кога  кометата поминува над нивните глави.', 38, 'https://www.youtube.com/watch?v=ygtoF9h9lcE'),
(39, 'Хорор', 'Derek Lee, ClifProwes', 6.3, 'ClifProwes, Derek Lee, Michael Gill, Benjamin Zeitoun, Jason Lee Gary Redekop, BayaRehaz', 'United States, Canada', 2013, 85, 'Две најдобри другарки патуваат низ својот живот, кога една од нив е погодена со страшна болка. Сега, во друга т.е туѓа земја тие се во борба како да се вратат назад, времето им истекува.', 39, 'https://www.youtube.com/watch?v=j2-p_Ma1I30'),
(40, 'Хорор', 'Ti West', 6.1, 'Joe Swanberg, Aj Bowen, KentuckerAudley, Kate Forbes, Amy Seimetz, Kate Lyn Sheil, Shaun Clay ', 'United States', 2013, 99, 'Човекот патува во светот на Eden Parish во потрага по својата изчезната сестра.', 40, 'https://www.youtube.com/watch?v=iP2rtrudKro'),
(41, 'Акција', 'Julius Avery', 6.6, 'Alicia Vikander, Ewan McGregor, Brenton Thwaites,  Matt Nable, Tammie West, Jacek Koman, Damon Herriman', 'Australia', 2014, 108, 'Излегуваат од затвор со Брендон Линч кои се водат како најпознати криминалци во Австралија. По некое време се приклчуваат на бадата Линч и никкако не можат да се одречат од криминалот. ', 41, 'https://www.youtube.com/watch?v=v6LQzRBDjA0'),
(42, 'Акција  ', 'Wes Ball', 6.9, 'Dylan O''Brien, Kaya Scodelario, Will Poulter, Chris Sheffield, Jacob Latimore, Patricia Clarkson, Alexander Flores', 'United States, United Kingdom, Canada', 2014, 113, 'Томас е депониран во една заедница на момчиња. Тој го губи целото паметење, т.е му се брише цела меморија од главата. Повеќе момчиња се заглавени во лавиринтот од кои не можат да излезат.', 42, 'https://www.youtube.com/watch?v=Xv8ffeBcRC8'),
(43, 'Акција  ', 'Antoine Fuqua', 7.2, 'Denzel Washington, Marton Csokas, Chloë Grace Moretz, David Meunier, Alex Veadov, Bill Pullman', 'United States', 2014, 132, 'Еден човек верува дека може да го остави минатото и да започне нов и мирен живот. Сето тоа трае додека не сретне некоја млада девојка на која мора да и помогне.', 43, 'https://www.youtube.com/watch?v=fQSUGMtDCtk'),
(44, 'Акција  ', 'Gary Shore', 6.3, 'Luke Evans, Dominic Cooper, Sarah Gadon, Zach McGowan, Ronan Vibert, Noah Huntley', 'United States', 2014, 92, 'На неговото царство се заканува опасност од Турците. Младиот принц Влад Тепеш мора да стане чудовиште за да го плаши својот народ со цел да собере сила и да го заштити своето семејство.', 44, 'https://www.youtube.com/watch?v=hZFZxEnB7ws'),
(45, 'Акција  ', 'Sarik Andreasyan', 5, 'Hayden Christensen, Jordana Brewster, Adrien Brody, Tory Kittles, Elena Sanchez, Divine Prince Ty Emmecca', 'Canada', 2014, 94, 'Двајца браќа повторно со своите проблеми се наоѓаат во средина на една поранешна банка.', 45, 'https://www.youtube.com/watch?v=QY_IOn0fsc0'),
(46, 'Акција  ', 'Neil Burger', 6.8, 'Shailene Woodley, Theo James, Kate Winslet, Miles Teller, Tony Goldwyn, Jai Courtney, Jai Courtney', 'United States', 2014, 143, 'Во светот поделен од факти врз основа на добродетели, Трис дознава не може да се вклопи внатре. Таа се спријателува и прави заговор за да се уништи Дивергент, пред да биде предоцна.', 46, 'https://www.youtube.com/watch?v=HkSSTuWtTTg'),
(47, 'Акција', 'Robert Stromberg', 7.1, 'Angelina Jolie, Elle Fanning, Sharlto Copley, Imelda Staunton, Sam Riley, Juno Temple, Brenton Thwaites', 'United States, United Kingdom', 2014, 97, 'Самовилите се принудени да се заколнат во новороденчето се со цел за да откријат дека детето може да биде еден човек кој може да го врати мирот на својата несреќна земја.', 47, 'https://www.youtube.com/watch?v=uM_9KvLutsA'),
(48, 'Акција', 'Emilis Velyvis', 7.2, 'Vinnie Jones, Scot Williams, Gil Darnell, Andrius Ziurauskas, Oliver Jackson, Monika Vaiciulyte ', 'United Kingdom', 2014, 99, 'Четворица пријатели Џон, Бен, Тим и Мајкл се заглавени во Источна Европа и го бараат патот за да се вратат назад. За да се вратат дома тие мора да поминат низ големи мажи, корумпирани полицајци, шверцери и уште многу проблеми.', 48, 'https://www.youtube.com/watch?v=TSAMhY0jCdQ'),
(49, 'Акција  ', 'Darren Aronofsky', 5.9, 'Russell Crowe, Jennifer Connelly, Anthony Hopkins, Emma Watson, Douglas Booth, Logan Lerman', 'United States', 2014, 139, 'Еден човек е избран од страна на неговиот свет да изврши значајна мисија. Светот се наоѓа пред апокалиптична поплава и тој треба да го спаси.', 49, 'https://www.youtube.com/watch?v=_OSaJE2rqxU'),
(50, 'Акција  ', 'Gareth Edwards', 6.6, 'Aaron Taylor-Johnson, Elizabeth Olsen, Bryan Cranston, Sally Hawkins, David Strathairn', 'United States, Japan', 2014, 123, 'Најпознатото светско чудовиште се спротивставува на злобни суштества кои се повеќе зајакнуваат со помош на научните истражува од страна на човекот.', 50, 'https://www.youtube.com/watch?v=vIu85WQTPRc'),
(51, 'Акција  ', 'David Hayter', 5.2, 'Lucas Till, Stephen McHattie, John Pyper-Ferguson, Jason Momoa, Philip Maurice Hayes, Adam Butcher', 'France, Canada', 2014, 90, 'Едно момче се обидува да дознае за неговот семејство. Неговата историја, наследство, но наидува на неочекуван проблем.', 51, 'https://www.youtube.com/watch?v=NTlHVvvC4U0'),
(52, 'Акција  ', 'Brett Ratner', 6.1, 'Dwayne Johnson, John Hurt, Ian McShane, Aksel Hennie, Peter Mullan, Tobias Santelmann', 'United States ', 2014, 99, 'Тој е многу славен и се прослави со дванаесет победи. Кралот на Тракија и неговата ќерка бараат помош за да го победи тиранскиот воен диктатор.', 52, 'https://www.youtube.com/watch?v=OwlynHlZEc4'),
(53, 'Акција  ', 'Adam Wingard', 6.7, 'Dan Stevens, Sheila Kelley, Maika Monroe, Lance Reddick, Joel David Moore, Chase Williamson', 'United States', 2014, 99, 'Еден војник се претставува на семејството Петерсон, тврдејќи дека е пријател на нивниот син кој починал во акција. По неговото доаѓање започнува да се сомневаат во него за раната смрт на нивниот син.', 53, 'https://www.youtube.com/watch?v=y0E2Qh6wLS4'),
(54, 'Акција  ', 'Nick Powell', 4.5, 'Nicolas Cage, Hayden Christensen, Andy On, Jawed El Berni, Fernando Chien, Preston Baker', 'United States, United Kingdom, France', 2014, 98, 'Мисетериозниот воен тим заедно со ќерката и синот на соборениот кинески цар заминуваа во борба со своите сурови браќа. Тоа го прават бидејќи тие ја имаат за цел нивната смрт.', 54, 'https://www.youtube.com/watch?v=vE-MLWqME0g'),
(55, 'Акција  ', 'Jaume Collet-Serra', 7, 'Liam Neeson, Julianne Moore, Scoot McNairy, Corey Stoll, Omar Metwally, Jason Butler Harner', 'United States, United Kingdom, France ', 2014, 106, 'Воздушен маршал започнува со напорна работа на прекуокеански лет, со помош на текстуалните пораки кои ги оставаат неговите колеги.', 55, 'https://www.youtube.com/watch?v=jiHDJ19A3dk'),
(56, 'Акција  ', 'Vic Armstrong', 3.1, 'Nicolas Cage, Lea Thompson, Cassi Thomson, Quinton Aaron, Martin Klebba, Jordin Sparks', 'Canada', 2014, 110, 'Една мала група на луѓе го преживува немилиот настан. Исчезнуваат милиони луѓе, а светот се втурнува во хаос и уништување.', 56, 'https://www.youtube.com/watch?v=GrXe8YDbzYs'),
(57, 'Акција  ', 'David Field and George Basha', 4.8, 'George Basha, Richard Green, Brian Ellison, Tony Ryan, Brendan Donoghue, David Roberts', 'Australia', 2014, 110, 'Реј е испратен во затвор поради убиство. Тој е испрашуван и измачуван физички и психички во затворот од страна на шефот.', 57, 'https://www.youtube.com/watch?v=_2voogORjo0'),
(58, 'Акција  ', 'Kathryn Bigelow', 7.2, 'Patrick Swayze, Keanu Reeves, Gary Busey, Lori Petty, James Le Gros, John Philbin', 'United States, Japan', 1991, 120, 'Агент на ФБИ оди на тајна задача. Задачата навидум изгледа лесна, но треба да се зароби една банда која ја напаѓа банката.', 58, 'https://www.youtube.com/watch?v=UuVDrpl1tIY'),
(59, 'Акција  ', 'José Padilha', 6.3, 'Joel Kinnaman, Gary Oldman, Michael Keaton, Abbie Cornish, Michael Kenneth Williams', 'United States', 2014, 102, 'Во 2028 во Детроит, Алекс Марфи - е љубовен сопруг, татко и добар полицаец. Во една акција тој е сериозно повреден при вршење на службената должност.', 59, 'https://www.youtube.com/watch?v=UuVphAuRo7Q'),
(60, 'Акција  ', 'Justin Lin', 7.2, 'Vin Diesel, Paul Walker, Dwayne Johnson, Jordana Brewster, Michelle Rodriguez,  Tyrese Gibson', 'United States', 2013, 130, 'Хобс го има Доминик и Брајан како составни членови на екипажот. Доминик неочекувана информација дека починатата девојка можеби е Лети.', 60, 'https://www.youtube.com/watch?v=dKi5XoeTN0k'),
(61, 'Акција  ', 'McG', 6.2, 'Kevin Costner, Hailee Steinfeld, Connie Nielsen, Bruno Ricci, Richard Sammel, Marc Andréoni', 'United States, France, Greece,  Russia', 2014, 113, 'Во тешка состојба е еден ЦИА агент. Тој се обидува да се поврзе со своите ќерки кои можат да пронјдат експириментален лек кој може да му го спаси животот. Во замена за неговиот живот од нив се бара да ја извршат последната задача.	', 61, 'https://www.youtube.com/watch?v=yswZKfnmf7c'),
(62, 'Акција  ', 'Tim Story', 6.1, 'Ice Cube, Kevin Hart, Tika Sumpter, Bruce McGill, Tika Sumpter, Laurence Fishburne', 'United States', 2014, 99, 'Безбедносните служби на Бен, мора да докажат дека братот на неговата девојка е полицаецот Џејмс. Тој вози заедно со Џејмс на 24-часновна патрола низ Атланта.', 62, 'https://www.youtube.com/watch?v=5klp6rkHIks'),
(63, 'Драма', 'Richard Raymond', 5.2, 'Freida Pinto, NazaninBoniadi and Reece Ritchie', 'United States', 2014, 98, 'Во Иран се забранува да танцуваат. И покрај опасностите нејзините пријатели одлучуваат да започнат со подземена танц група. ', 63, 'https://www.youtube.com/watch?v=HYCIXaP6pKQ'),
(64, 'Драма', 'Stuart Murdoch', 6.5, 'Emily Browning, Olly Alexander and Hannah Murray', 'United Kingdom', 2014, 112, 'Првотo музичко сценарио и режија на Стјуарт Мардок, додека лидери на поп група се Бел и Себастијан. Ева е млад пејач кој се обидува да излезе од депресијата со пишување песни. ', 64, 'https://www.youtube.com/watch?v=1zYFJHaZO_Y'),
(65, 'Драма', 'Peter Glanz', 5.4, ' Jason Bateman, Olivia Wilde, Billy Crudup', 'United States', 2014, 86, 'Конрад Valmont никогаш не работел во неговиот живот, и се уште се одржуваат од страна на неговите родители. До денот кога тоа престанало , што го принуди да  најде домување и вработување. Неговиот најдобар пријател, Дилан, го поздрави и презентирани со неговиот најнов освојување, Беатрис, вклучувајќи Конрад се заљубува . Проблемите на вработување, домување и срцето, тој има една недела да поправат сè.', 65, 'https://www.youtube.com/watch?v=Qwu51SYfQQs'),
(66, 'Драма', 'Ralph Ziman', 4.3, 'Brandy Schaefer, Zack Andrews and Bobby Roe', 'United States', 2014, 90, 'Сава живее во една пропадната држава, заработка во безбедносните сили со трговија со пари. Таа исто така работи во тајност како убиец. Кога беше дванаесет години, нејзиниот татко, кој е полицаец, убиен од страна на корумпиран колега, тој предизвика моќни противници со неговите инвестиции во полето на трговијата со жени .Сега, како една млада жена  Сава тргнува во потрага по убиецот и нивните поддржувачи во картел.', 66, 'https://www.youtube.com/watch?v=l0l7uphJ-Wg'),
(67, 'Драма', 'Ryan Phillippe', 5.1, 'Ryan Phillippe, TigNotaro and Joyful Drake', 'United States', 2014, 98, 'Новодојденец Реган Пирс го направи тоа. Холивуд лежи во неговите нозе, тој има се што би можеле да сакаат: слава, пари и жени. Но, кога тој е киднапиран од страна на наводен возачот пред неговиот хотел, патување започнува во сенка на светот на успех. Неговите брутални киднаперите цврсто верува дека актерот имал врски со неговата сопруга. Заробеници во кабина далеку од сите, помош која му треба да го трпи го лути и измачува.', 67, 'https://www.youtube.com/watch?v=zmdMQ-FszGQ'),
(68, 'Трилер', 'Richard Gray', 5.9, 'Justin Long, Gillian Jacobs, John Corbett', 'United States', 2014, 115, 'Баронот на дрогата Вилијам Спинкс е опседнат со Сади иги користи своите пријатели Боби и Френк за да се доближи до неа. ', 68, 'https://www.youtube.com/watch?v=vh2RPh1LXAM'),
(69, 'Трилер', 'Steven Quale', 6.2, 'Richard Armitage, Sarah Wayne Callies and Matt Walsh', 'United States', 2014, 135, 'Градот Силвертон во еден ден е уништен од страна на невидена моќ т.е го зафаќа торнадо. Населението е на милост и немилост на непредвидливи и смртоносни циклони, бури, додека ловците предупредуваат дека најлошото допрва треба да дојде.', 69, 'https://www.youtube.com/watch?v=57Vkp77tVTM'),
(70, 'Трилер', 'Bobby Roe', 5.4, 'Brandy Schaefer, Zack Andrews and Bobby Roe', 'United States', 2014, 135, 'Пет пријатели за Ноќта на вештеркитетргнуваат на патување на  страшни места.', 70, 'https://www.youtube.com/watch?v=Yedl4lY9VgM'),
(71, 'Трилер', 'Brian A Miller', 4.5, 'Jason Patric, Bruce Willis and John Cusack', 'United States, United Kingdom', 2014, 135, 'Поранешен мафијаш треба да оди во Вегас да ја спаси својата ќерка. ', 71, 'https://www.youtube.com/watch?v=XdZuyp6DpnI'),
(72, 'Трилер', 'Derek Kolstad', 8, 'Keanu Reeves, Michael Nyqvist, Alfie Allen', 'United States, Canada', 2014, 135, 'Џон Фитил е професионален убиец, но сега е во пензија. Дојден е сторителот да му го краде неговиот автомобил 1969 Форд Мустангот.', 72, 'https://www.youtube.com/watch?v=2AUmvWm5ZDQ'),
(73, 'Трилер', 'Roger Donaldson', 6.6, 'Pierce Brosnan, Luke Bracey and Olga Kurylenko', 'United States', 2014, 135, 'Агентот Петер девераус повторно во неодолива акција за случај во Швајцарија. ', 73, 'https://www.youtube.com/watch?v=p2zFH8Zruqo'),
(74, 'Трилер', 'Hossein Amini', 6.4, 'Viggo Mortensen, Kirsten Dunst and Oscar Isaac', 'United Kingdom, France', 2014, 135, 'Еден млад сонародник Родал, кој се заљубил во девојката и сака да ја освои. Тој мора да го убие нејзиниот сопруг за да ја добие.', 74, 'https://www.youtube.com/watch?v=TrRHmhIDfjg'),
(75, 'Трилер', 'Brad Anderson', 6.9, 'Justin Long, Gillian Jacobs and John Corbett', 'United States', 2014, 135, 'На Бадник 1899 година, Едвард стигна до портите на Стоун Херст. Млад и неискусен психолог е во потрага по својата прва работа, за конечно да биде во можност да се здобие со практично искуство. ', 75, 'https://www.youtube.com/watch?v=rawTSQ1RKQ0'),
(76, 'Трилер', 'William Eubank', 6.2, 'BrentonThwaites, Olivia Cooke, Beau Knapp, Timothy Holmes, Laurence Fishburne', 'United States', 2014, 95, 'На едно патување Ник со своите двајца пријатели доживуваат голем успех, но тоа трае се додека Ник не се разбуди од сон и не сфати дека сонувал.', 76, 'https://www.youtube.com/watch?v=gwgfeR2pMuE'),
(77, 'Трилер', 'AjmalZaheer Ahmad', 4.3, 'Ray Park, Serinda Swan, William Atherton, Amber Whelan, Dominic Rains', 'United States', 2014, 97, 'Шон е успешен автомобилски дизајнер кој ужива во идиличен живот со неговата нова жена Јасмин.', 77, 'https://www.youtube.com/watch?v=JCp4_v9vopA'),
(78, 'Драма', 'Clint Eastwood', 7.7, 'John Lloyd Young, Erich Bergen, Michael Lomenda', 'United States', 2014, 134, 'Филм за животот на музичкиот бенд The Four Seasons, за нивното присуство, тешките времиња и конфликти. ', 78, 'https://www.youtube.com/watch?v=tL2iILHUsG0'),
(79, 'Драма', 'R.J. Cutler', 7.7, 'Liana Liberato, Gabrielle Rose, Jakob Davies', 'United States', 2014, 135, 'Таа е во болница, тука е и Адам кој е музичар, нејзината пријателка Ким  и нивните баби и дедо. Миа лебди во средниот светот и мора да одлучи дали да се врати во својот живот.', 79, 'https://www.youtube.com/watch?v=rMp896hfp74'),
(80, 'Драма', 'Phillip Noyce', 6.5, 'BrentonThwaites, Jeff Bridges and Meryl Streep', 'United States', 2014, 97, 'Дарителот гарантира дека никој не треба да чувствуваповеќе негативни емоции, но не се сите задоволни со тоа. ', 80, 'https://www.youtube.com/watch?v=xvp6FnYWRZU'),
(81, 'Драма', 'Randall Wallace', 5.8, 'Greg Kinnear, Kelly Reilly, Thomas Haden Church, Connor Corum, Margo Martindale', 'United States', 2014, 99, 'Еден татко ги сносува сите последици кои ги нуди разведен брак со неговиот син.', 81, 'https://www.youtube.com/watch?v=MZrHZJTPQCo'),
(82, 'Драма', 'Chris Eska', 6.6, 'Ashton Sanders, Tishuan Scott, Keston John, Alfonso Freeman, Christine Horn', 'United States', 2014, 91, 'На периферијата на Американската граѓанска војна, едно момче е испратено на север да војува.', 82, 'https://www.youtube.com/watch?v=arvuMKRHtbA'),
(84, 'Комедија', 'Max \nNichols\n', 6.4, 'Miles Teller, Analeigh Tipton, Jessica Szohr, Scott Mescudi, Josh Salatin, Berto Colon  ', 'United States', 2014, 86, 'Две лица кои се конектираа на интернет една ноќ, неволно останаа во текот на целата ноќ. ', 84, 'https://www.youtube.com/watch?v=VcSosCe0B-A'),
(85, 'Комедија', 'Theodore Melfi', 7.3, 'Bill Murray, Melissa McCarthy, Naomi Watts, Chris O''Dowd, Terrence Howard, JaedenLieberher', 'United States', 2014, 102, 'Младо момче чии што родители се разведени на оѓа еден неверјатно добар пријател. Добар, грижлив за него, ветеран кој има што да му раскажува на момчето.', 85, 'https://www.youtube.com/watch?v=9dP5lJnJHXg'),
(86, 'Комедија', 'Jake Kasdan', 5.1, 'Jason Segel, Cameron Diaz, Rob Corddry, Ellie Kemper, Rob Lowe, Nat Faxon, Nancy Lenehan', 'United States', 2014, 97, 'Брачен пар една ноќ се снима додека водат љубов. Ова не е воопшто необично, туку проблемот настанува кога наредниот ден снимката од нив е најдена, а тие двајца се водат за исчезнати.', 86, 'https://www.youtube.com/watch?v=NyIRTDpFlvc'),
(87, 'Комедија', 'Ben Falcone', 4.8, 'Melissa McCarthy, Susan Sarandon, Kathy Bates, Mark Duplass, Dan Aykroyd, Allison Janney', 'United States', 2014, 98, 'Поболниот пораз кој го доживеа на работа, таа открива дека нејзиниот маж не и е верен.', 87, 'https://www.youtube.com/watch?v=N8d6Bpl2eAo'),
(89, 'Комедија', 'Jon Favreau', 7.3, 'Jon Favreau, Robert Downey Jr., Scarlett Johansson, Scarlett Johansson, Dustin Hoffman  ', 'United States', 2014, 115, 'Супер готвач во ресторант ја губи работата, па започнува работа со камион каде што разнесува храна.', 89, 'https://www.youtube.com/watch?v=wgFws3AoIUY'),
(90, 'Комедија', 'Matthew Warchus', 7.9, 'Bill Nighy, Imelda Staunton, Dominic West, Joseph Gilgun, Andrew Scott, Monica Dolan    ', 'France', 2014, 117, 'Во 1984 година, летно време во Велика Британија им се нуди помош на рударите за време на нивниот долг штрајк.', 90, 'https://www.youtube.com/watch?v=kZfFvsKDuUU'),
(91, 'Комедија', 'Nathan Greno, Byron Howard', 7.9, 'Mandy Moore, Zachary Levi, Donna Murphy, Ron Perlman, Jeffrey Tambor, Brad Garrett', 'United States', 2010, 100, 'Таа има магично долга руса коса, но целиот свој живот го поминува во една кула затворена, се додека не ја најде едно момче.', 91, 'https://www.youtube.com/watch?v=pyOyBVXDJ9Q');
INSERT INTO `sekojfilm` (`detali_id`, `kategorija`, `rezija`, `ocena`, `akteri`, `drzava`, `godina`, `vremetraenje`, `sodrzina`, `film_id`, `official_trailer`) VALUES
(92, 'Комедија', 'Michael Dowse', 6.9, 'Daniel Radcliffe, Zoe Kazan, Megan Park, Mackenzie Davis, Lucius Hoyos, Rafe Spall ', 'Ireland, Canada', 2013, 93, 'Волас е изгорен од голем број на неуспешни врски позади него, а е долгогодишен пријател со Кантри која живее со своето момче.  Проблемите настануваат кога тие сфаќаатдека и најдобриот е пријатели може да се вљубат еден во друг.', 92, 'https://www.youtube.com/watch?v=A86JGbBEaBk'),
(93, 'Комедија', 'Evan Goldberg, Seth Rogen', 6.7, 'James Franco, Jonah Hill, Seth Rogen, Jay Baruchel, Craig Robinson, Danny McBride  ', 'United States', 2013, 107, 'Додека трае забавата која се состои од голем број на познати личности сите се соочуваат со апокалипса.', 93, 'https://www.youtube.com/watch?v=Yma-g4gTwlE'),
(94, 'Комедија', 'Pierre Coffin, Chris Renaud', 7.7, 'Steve Carell, Jason Segel, Russell Brand, Will Arnett, Julie Andrews, Russell Brand ', 'United States', 2010, 95, 'Извршува кривично дело на три девојки сирачиња кога сфаќа дека нивната љубов длабоко го менува.', 94, 'https://www.youtube.com/watch?v=uW8HDrKYisc'),
(95, 'Комедија', 'Chris Columbus', 7.4, 'Macaulay Culkin, Joe Pesci, Daniel Stern, John Heard, Roberts Blossom, Angela Goethals ', 'United States', 1990, 103, '8-годишното куче треба да си го спаси својот дом од еден пар на провалници, кога тој е случајно оставен сам дома додека неговото семејство е на Божиќен одмор.', 95, 'https://www.youtube.com/watch?v=ddflK6Km_78'),
(96, 'Комедија', 'Matthew Weiner', 5.3, 'Owen Wilson, Zach Galifianakis, Amy Poehler, Melissa Rauch, Zach Galifianakis, Naomi Lavette ', 'United States', 2014, 114, 'Две девојки кои од детство се најдобри пријателки се враќаат заедно во својот роден крај.', 96, 'https://www.youtube.com/watch?v=uMtNpu6xBvU'),
(97, 'Комедија', 'Tony Mahony, Angus Sampson', 6.3, 'Hugo Weaving, Angus Sampson, Leigh Whannell, Georgina Haig, John Noble, Nick Farnell ', 'Australia', 2014, 103, 'За прв пат е фатен со дрога во себе од страна на полицијата.', 97, 'https://www.youtube.com/watch?v=DIswOv8DEx8'),
(98, 'Комедија', 'Shawn Levy', 6.3, 'Vince Vaughn, Owen Wilson, Rose Byrne, Josh Brener, Max Minghella, AasifMandvi', 'United States', 2013, 119, 'Двајца трговци чии кариери се доста успешни ќе треба да одржат натпревар за повисоко работно место помеѓу себе.', 98, 'https://www.youtube.com/watch?v=cdnoqCViqUo'),
(99, 'Комедија', 'Mark Waters', 5.6, 'ZoeyDeutch, Lucy Fry, DanilaKozlovsky, Gabriel Byrne, Dominic Sherwood, Olga Kurylenko', 'United States, Romania', 2014, 104, 'Роуз Хатвеј е половина човек-половина вампир. Нејзина цел е да ги заштити луѓето од вампирите.', 99, 'https://www.youtube.com/watch?v=E1ERrnYunBg'),
(100, 'Комедија', 'Paul Feig', 6.7, 'Sandra Bullock, Michael McDonald, Melissa McCarthy, Michael Rapaport, Marlon Wayans', 'United States', 2013, 117, 'Еден ФБИ агент е поврзан со дрога во Бостон. Тој упорно тврди дека не е виновен.', 100, 'https://www.youtube.com/watch?v=RDiaXZiIJOQ'),
(101, 'Комедија', 'Jason Bateman', 6.7, 'Jason Bateman, Kathryn Hahn, Allison Janney, Philip Baker Hall, Ben Falcone, Steve Witting', 'United States', 2013, 88, 'Еден правописник ги подредува точно зборовите.', 101, 'https://www.youtube.com/watch?v=yXoZCAVTzEQ'),
(102, 'Комедија', 'Lenny Abrahamson', 7, 'Michael Fassbender, Domhnall Gleeson, Maggie Gyllenhaal, Maggie Gyllenhaal, Scoot McNairy', 'United States, Ireland', 2014, 96, 'Џон е млад музичар кога открива дека тој повеќе може да каса, отколку да ја џвака храната.', 102, 'https://www.youtube.com/watch?v=-catC4tBVyY'),
(103, 'Комедија', 'Rob Thomas', 6.9, 'Kristen Bell, Jason Dohring, Enrico Colantoni, Tina Majorino, Krysten Ritter, Chris Lowell', 'United States', 2014, 107, 'Години откако си замина од нејзиното минато како тинејџерка, Вероника Марс мора повторно да се врати во својот роден град. И што ја очекува? Ќе се изненади и таа.', 103, 'https://www.youtube.com/watch?v=iksrM_LNZ6s'),
(104, 'Комедија', 'Chris Nelson', 5.7, 'Nicholas Braun, Hunter Cope, Dakota Johnson, Jennifer Clement, Darien Provost, Megan Mullally', 'United States', 2014, 91, 'Две момчиња се договараат т.е прават пакт помеѓу нив дека ќе водат љубов со девојка за време на матурската вечер.', 104, 'https://www.youtube.com/watch?v=ggehO3r1hMM'),
(105, 'Комедија', 'Jon S. Baird', 7.1, 'James McAvoy, Jamie Bell, Eddie Marsan, Brian McCardie, Emun Elliott, Imogen Poots', 'United States, Germany, Belgium', 2013, 97, 'Еден корумпиран полицаец манипулира на една промоција, се со цел да си ги врати својата жена и ќерка.', 105, 'https://www.youtube.com/watch?v=tymWDB7gtK4'),
(106, 'Комедија', 'Paul Weitz', 5.7, 'Tina Fey, Paul Rudd, Nat Wolff, Maggie Keenan-Bolger, Paul Rudd, Gloria Reuben', 'United States', 2013, 103, 'Таа се запознава со едно дете од училиште, кое ќе се одкаже пред самиот крај на долгогодишната борба.', 106, 'https://www.youtube.com/watch?v=3w0mN9A9cAU'),
(124, 'Хорор', 'John R. Leonetti', 5.5, 'Ward Horton, Annabelle Wallis, Alfre Woodard, Eric Ladin, IvarBrogger, Kerry O''Malley', 'United States', 2014, 99, 'Некои луѓе доживуваат појавување на застрашувачки натприродни појави. Вклучувајќи гроздобер кукла, за кратко време им ја напаѓа нивната куќа.', 124, 'https://www.youtube.com/watch?v=jdUysoK6tdQ'),
(125, 'Хорор', 'Stiles White', 4.4, 'Olivia Cooke, Ana Coto, Daren Kagasoff , Shelley Hennig, Douglas Smith, Sunny May Allison', 'United States', 2014, 89, 'Група на пријатели мора да се соочат со своите најстрашни стравови, кога сфаќаат дека многу тешко им оди тоа.', 125, 'https://www.youtube.com/watch?v=_T1Jj1inE8M'),
(126, 'Хорор', 'James DeMonaco', 6.5, 'Frank Grillo, Carmen Ejogo, Zach Gilford, John Beasley, Jack Conley, Justina Machado', 'United States, France', 2014, 104, 'Три групи на луѓе се обидуваат да ја преживеат ноќта без последици. Но, проблемите настануваат кога нивните животи ќе им се испреплетат и ќе ги остават на цедило. Со сите сили се обидуваат да го преживеат хаосот и насилствто.', 126, 'https://www.youtube.com/watch?v=q1r5hBcq7tI'),
(127, 'Хорор', 'Jennifer Kent', 6.9, 'Essie Davis, Noah Wiseman, Daniel Henshall, Tim Purcell, Hayley McElhinney, Benjamin Winspear', 'Australia, Canada', 2014, 83, 'Самохрана мајка измачувана од страна на својот покоен сопруг доживува повторно страв и немир од страна на чудовишта кои јаде на нејината куќа. Таа живее со својот син кој се труди барем него да го смири.', 127, 'https://www.youtube.com/watch?v=k5WQZzDRVtw'),
(128, 'Хорор', 'Matthew A. Brown', 5.1, 'Ashley C. Williams, TahynaTozzi, Jack Noseworthy, Darren Lipari, Cary Woodworth', 'United States', 2014, 95, 'Јулија е девојка со преживеана траума и моментално е на терапија. Но, не кои насилства едноставно не можат да се надминат.', 128, 'https://www.youtube.com/watch?v=YpIM2WwHqWg'),
(129, 'Хорор', 'Jim Jarmusch', 7.3, 'TildaSwinton, Tom Hiddleston, Mia Wasikowska, Jeffrey Wright, SlimaneDazi, Mia Wasikowska ', 'Germany, France, Greece', 2013, 123, 'Депресивен музичар заљубен во својата девојка, се додека нема да се појави неговата помлада сестра и ќе направи страшен хаос.', 129, 'https://www.youtube.com/watch?v=ycOKvWrwYFo'),
(130, 'Хорор', 'Brett Simmons', 4.6, 'Joey Lauren Adams, Elizabeth Gillies, Paul Iacono, Keke Palmer, Thorsten Kaye, AmauryNolasco', 'United States', 2014, 86, 'Кога плановите за викенд толку кобно завршија за една мала група на парови. Тие запаѓаат во ќорсокак и излегуваат на непозната територија.', 130, 'https://www.youtube.com/watch?v=U5oqL27Wgxs'),
(131, 'Хорор', 'Mike Flanagan', 6.5, 'Karen Gillan, BrentonThwaites, KateeSackhoff, Annalise Basso, Garrett Ryan, James Lafferty', 'United States', 2014, 104, 'Една жена се обидува да го ослободи нејзиниот брат, кој беше осуден за убиство. За неговиот злочин се тврди дека делото е извршено од страна на натприродна појава.', 131, 'https://www.youtube.com/watch?v=dYJrxezWLUk'),
(132, 'Хорор', 'James Watkins', 6.5, 'Daniel Radcliffe, Janet McTeer, Ciarán Hinds, Misha Handley, Roger Allam, Sophie Stuckey', 'Canada, Sweden', 2012, 95, 'Еден млад адвокат патува во зафрлено село каде што тој здогледува жена дух која го тероризира локалното население.', 132, 'https://www.youtube.com/watch?v=7lReemWmO5o'),
(133, 'Хорор', 'John Erick Dowdle', 6.1, 'Perdita Weeks, Ben Feldman, Edwin Hodge, Ali Marhyar, Marion Lambert, Cosme Castro', 'United States', 2014, 93, 'Кога еден тим на истражувачи работат на улиците на Париз, тие наидуваат на една темна тајна која лежи во овој град на мртвите.', 133, 'https://www.youtube.com/watch?v=GRrZZNyOqyY'),
(134, 'Хорор', 'Stanley Kubrick', 8.5, 'Jack Nicholson, Shelley Duvall, Danny Lloyd , Barry Nelson, Joe Turkel, Anne Jackson', 'United States', 1980, 144, 'Семејство заминува во хотел во зима на скијање. Кога главата на семејствотото е таткото прогонуван, а неговиот син гледа ужасни работи од минатото и иднината.', 134, 'https://www.youtube.com/watch?v=5Cb3ik6zP2I'),
(135, 'Хорор', 'Gerard Johnstone', 6.8, 'Morgana O''Reilly, Rima TeWiata, Glen-Paul Waru , Millen Baird, Bruce Hopkins, Mick Innes', 'United States', 2014, 109, 'Кајли Буцкнел е принуден да се врати во куќата што израснал кога судот ја казнува на домашен притвор. Нејзината казна е уште поголема и не поднослива со самиот факт што таа ќе живее таму со нејзината мајка Мириам која е убедена дека куќата е опседната.', 135, 'https://www.youtube.com/watch?v=vX0DsoiXIho'),
(136, 'Хорор', 'Blair Erickson', 5.5, 'Katia Winter, Ted Levine, Michael McMillian, Corey Moosa, Vivian Nesbitt, Jenny Gabrielle ', 'United States, Germany', 2014, 87, 'Новинарката Ана Роланд истражува за вознемирувачки линкови кои стојат позади исчезнување нејзината пријателка.', 136, 'https://www.youtube.com/watch?v=_D-qNaThvcU'),
(137, 'Хорор', 'David Campbell', 3.7, 'Jessica Tovey, Nicholas Gunn, Pippa Black, Tim Pocock, Andrew Ryan, Tim Phillipps', 'United States', 2014, 84, 'Неколку Австралијанци воведуваат тројца американски туристи на локалната легендана Лимон. Погледањето на духот тие наидуваат на злобни сили кои ги поседува областа и се заканува да ги опустошат нивните последни денови од годишен одмор.', 137, 'https://www.youtube.com/watch?v=h8gJ7SH73D4'),
(138, 'Хорор', 'Scott Derrickson', 6.8, 'Ethan Hawke, Juliet Rylance, James Ransone, Clare Foley, Rob Riley, James Ransone ', 'United States, Canada', 2012, 110, 'Писател открива вистински криминал од страна на еден сериски убиец.', 138, 'https://www.youtube.com/watch?v=4InFwCO3bOs'),
(139, 'Хорор', 'Matty Beckerman ', 4.8, 'Katherine Sigismund, Corey Eid, Riley Polanski, Jeff Bowser, Peter Holden, Jordan Turchin ', 'United States', 2014, 85, 'Едно семејство е на годишен одморво Северна Каролина, кога настануваат проблемите. ', 139, 'https://www.youtube.com/watch?v=4zLS4lL3JDQ'),
(140, 'Хорор', 'Andrés Muschietti', 6.2, 'Jessica Chastain, NikolajCoster-Waldau, Megan Charpentier, Javier Botet, Isabelle Nélisse  ', 'Canada, Spain', 2013, 100, 'Анабел и Лукас се соочуваат со предизвикот на подигнување на неговите млади внуки, кои беа оставени сами во шумата на 5 години ....но како сами биле тие таму?', 140, 'https://www.youtube.com/watch?v=R2nwknMmvdc'),
(141, 'Хорор', 'Daniel Stamm', 6.2, 'Mark Webber, Devon Graye, Tom Bower, Pruitt Taylor Vince, Ron Perlman, Rutina Wesley', 'United States', 2014, 88, 'Елиот се впушта во опасна игра на ризици кои на товар носи 13 задачи, секоја потешка од претходната.', 141, 'https://www.youtube.com/watch?v=lQobCHDeEo8'),
(142, 'Хорор', 'John Carpenter ', 8.2, 'Kurt Russell, Wilford Brimley, Keith David, David Clennon, Richard Dysart, Peter Maloney ', 'United States', 1982, 109, 'Човек, кој е специјализиран за паранормални појави открива чудни нешта во соба 1408 во хотелот Делфин.', 142, 'https://www.youtube.com/watch?v=5ftmr17M-a4'),
(143, 'Хорор', 'Mikael Håfström ', 6.8, 'John Cusack, Samuel L. Jackson, Mary McCormack, David Nicholson, Holly Hayes, Alexandra Silber', 'United States', 2007, 104, 'Човек, кој е специјализиран за паранормални појави открива чудни нешта во соба 1408 во хотелот Делфин.', 143, 'https://www.youtube.com/watch?v=WIASqPZqnhs'),
(144, 'Хорор', 'Zack Snyder ', 7.4, 'Sarah Polley, VingRhames, MekhiPhifer, Kevin Zegers, Lindy Booth, Jayne Eastwood ', 'United States, Canada, Japan', 2004, 101, 'Медицинска сестра, еден полицаец, млад брачен пар, еден продавач, и други преживеани од целиот свет се засолнуваат во еден трговски центар.', 144, 'https://www.youtube.com/watch?v=8LUzJAsa-gg'),
(145, 'Хорор', 'Marcus Nispel', 5.6, 'Jared Padalecki, Amanda Righetti, Derek Mears, JuliannaGuill, Jonathan Sadowski', 'United States', 2009, 103, 'Една група на млади луѓе отишле на кампување, каде на брзо ќе се сретнат со Џејсон и неговите смртоносни намери.', 145, 'https://www.youtube.com/watch?v=o50beX0Gzq4');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
