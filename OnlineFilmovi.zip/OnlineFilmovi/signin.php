<!DOCTYPE html PUBLIC >
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link href="css/stilovi1.css" rel="stylesheet" type="text/css">
    <title>ФИЛМСКИ маратон</title>
<!--    <style type="text/css" charset="utf-8">-->
<!--        @import url("stilovi.css");-->
<!--    </style>-->
</head>
<body background="images/login.jpg" ;width=100%; height=100%;>
    <br />
	<br />
<div class="logo">
    <img src="images/logo.png" width="100" height="100"> <span class="logo_font" id="logo_title"></span><img src="images/logo.png" width="100" height="100">
<?php
    include 'db_sign.php';
    if(isset($_SESSION['signed_in']) && $_SESSION['signed_in'] == "true"){
        echo 'Вие сте веќе логирани, можете да се <a href="signout.php">одјавете овде</a> доколку сакате.';
    }else{
        if($_SERVER['REQUEST_METHOD'] != 'POST'){
            ?>

    <form method="post" action="">
</div><!--logo-->
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		Корисничко име&nbsp;&nbsp;<input type="text" name="username" />
	<br />
	<br />
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        Лозинка &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password" name="password" />
    <br />
	<br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="image" src="images/2.png"  name="submit" >
	<br />
	<br />
	<br />
</form>
	<br />



            <?php
        }else{
            $errors = array();
            if(empty($_POST['username']))
            {
                $errors[] = 'Корисничкото име не смее да биде празно.';
            }
            if(empty($_POST['password']))
            {
                $errors[] = 'Морате да внесете лозинка.';
            }
            if(!empty($errors))
            {
                echo "<br/><br/><br/><br/><br/><br/><br/>";
                echo '<ul>';
                foreach($errors as $value)
                {
                    echo '<li style="color:#696969">' . $value . '</li>';
                }

                echo '<br><li style="color: #696969"><a href="signin.php">Обидете се повторно.</a></li>';
                echo '</ul>';
            }else{

                //formata e ispratena bez greshki
                $sql = "SELECT *
                    FROM
                        korisnici
                    WHERE
                        username = '" . mysqli_real_escape_string($db, $_POST['username']) . "'
                    AND
                        lozinka = '" .
                    sha1($_POST['password']) . "'";

                $result = mysqli_query($db, $sql);

                if(!$result)
                {
                    echo "<br/><br/><br/><br/><br/><br/><br/><br/><br/>";
                    echo 'Настанал проблем за време на најавата. Ве молиме обидете се подоцна.';
                    echo mysql_error();
                }
                else
                {
                    if(mysqli_num_rows($result) == 0)
                    {
                        echo "<br/><br/><br/><br/><br/><br/><br/>";
                        echo 'Такво корисничко име/лозинка <br>не постојат во базата.<br>Доколку сакате <a href="signin.php">обидете се повторно.</a>';
                    }
                    else
                    {
                        $_SESSION['signed_in'] = 'true';
                        while($row = mysqli_fetch_assoc($result))
                        {
                            $_SESSION['user_id']    = $row['kluc'];
                            $_SESSION['user_name']  = $row['username'];
                        }
                        echo "<br/><br/><br/><br/><br/><br/><br/><br/><br/>";
                        echo 'Добредојдe,  ' . $_SESSION['user_name'] . '.<br><br><a href="index.php">Можеш да продолжиш понатаму :)</a>.';
                    }
                }
            }
        }
    }

    ?>

        <script type="text/javascript">
            var title="Online филмови во секое време ";
            var title1 = "";
            var first_char;
            var logo_title = document.getElementById('logo_title');
            logo_title.innerText = title;

            function do_something(){
                if (title == ""){
                    title = title1;
                    title1 = "";
                    logo_title.innerText = title;
                    //alert(title);
                    console.log("11");
                    logo_title.innerText = title;
                    setTimeout("wait(2000)", 0.001);
                } else {
                    first_char = title[0];
                    title = title.substr(1);
                    title1 = title1 + first_char;
                    logo_title.innerText = title;
                    //console.log(title1);
                }
            }

            function wait(msecs)
            {
                var start = new Date().getTime();
                var cur = start
                while(cur - start < msecs)
                {
                    cur = new Date().getTime();
                }
            }

            function slider(){
                setInterval("do_something()", 50);
            }

            setTimeout("slider()", 2000);
        </script>
        </body>
        </html>