<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Ivana
 * Date: 2/6/15
 * Time: 1:38 PM
 * To change this template use File | Settings | File Templates.
 */
include 'db_sign.php';

   // unset($_SESSION['signed_in']);
    $_SESSION['signed_in'] = 'false';


//if(defined($_SESSION['user_id']))
unset($_SESSION['user_id']);

//if(defined($_SESSION['user_name']))
unset($_SESSION['user_name']);
//print_r($_SESSION['signed_in']);
header("location: index.php");