<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Stefi
 * Date: 1/17/15
 * Time: 2:00 PM
 * To change this template use File | Settings | File Templates.
 */
include'header.php';

$kategorija = mysqli_real_escape_string($db, $_GET['kategorija']);
if(($kategorija !== "akcija" && $kategorija !== "komedija" && $kategorija != "drama" && $kategorija != "triler" && $kategorija != "horor")){

    echo '<table width=100% border="0" style="margin-top: 80px;">';
    echo '<tr><td class="kategorija_pole">';
    echo '<div class="film_pole" style="color: white; font-size: 20px">Таква категорија не постои.</div><div class="film_pole"></div>';
    echo '</td></tr>';
    echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
    echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
    echo '</table>';

}else
{

    $rec_limit = 6;
    $sql_page = "SELECT count(ime) FROM filmovi";
    $retval = mysqli_query($db, $sql_page);
    if(! $retval )
    {
        die('Грешка при конекција со база: ' . mysqli_error($db));
    }
    $row_page = mysqli_fetch_array($retval, MYSQL_NUM );
    $rec_count = $row_page[0];
    if( isset($_GET['page'] ) )
    {
        $page = $_GET['page'] + 1;
        $offset = $rec_limit * $page ;
    }
    else
    {
        $page = 0;
        $offset = 0;
    }
    $left_rec = $rec_count - ($page * $rec_limit);

    $sql = 'select film_id, ime, slika
from filmovi, kategorija
where kategorija.kategorija_id = filmovi.kategorija_id and kategorija.kategorija_ime = "' . $kategorija . '"' . ' limit ' . $offset . ',' . $rec_limit;

$result = mysqli_query($db, $sql);

if(!$result)
{
    echo '<table width=100% border="0" style="margin-top: 80px;">';
    echo '<tr><td class="kategorija_pole">';
    echo '<div class="film_pole" style="color: white; font-size: 20px">Филмовите не можат да се прикажат во моментов. Обидете се подоцна.</div><div class="film_pole"></div>';
    echo '</td></tr>';
    echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
    echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
    echo '</table>';
}
else
{
    if(mysqli_num_rows($result) == 0)
    {
        echo '<table width=100% border="0" style="margin-top: 80px;">';
        echo '<tr><td class="kategorija_pole">';
        echo '<div class="film_pole" style="color: white; font-size: 20px">Нема внесено филмови во базата.</div><div class="film_pole"></div>';
        echo '</td></tr>';
        echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
        echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
        echo '</table>';

    }
    else {

        echo '<table width=100% border="0" style="margin-top: 80px;">';
        echo '<tr><td class="kategorija_pole">';

        while($row = mysqli_fetch_assoc($result)){
            echo '<div class="film_pole">'.
                '<a href="detali.php?id=' . $row['film_id'] . ' "><img src="' . $row['slika'] . '" width="250" height="400" border="0">'.
                '<p><center><font size="4" style="color:white">' . $row['ime'] . '</font></center></a>'.
                '</div>';
        }


        if( $page > 0 )
        {
            $last = $page - 2;
            echo "<div style='margin: 50px 250px; color: white'>";
            echo "<a style='color: white' href='" . $_SERVER['PHP_SELF'] . "?page=$last&kategorija=$kategorija'>Претходно</a> |";
            echo "<a style='color: white' href='" . $_SERVER['PHP_SELF'] . "?page=$page&kategorija=$kategorija'>Следно</a>";
            echo "</div>";
        }
        else if( $page == 0 )
        {
            echo "<div style='margin: 50px 300px; color: white'>";
            echo "<a style='color: white' href='" . $_SERVER['PHP_SELF'] . "?page=$page&kategorija=$kategorija'>Следно</a>";
            echo "</div>";
        }
        else if( $left_rec < $rec_limit )
        {
            $last = $page - 2;
            echo "<div style='margin: 50px 300px; color: white'>";
            echo "<a style='color: white' href='" . $_SERVER['PHP_SELF'] . "?page=$last&kategorija=$kategorija'>Претходно</a>";
            echo "</div>";
        }


        ?>

    <?php
        echo '</td></tr></table>';
    }
}
}
include 'footer.html';
?>