<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" >
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Филмски Маратон</title>
    <meta name="ROBOTS" content="NOINDEX, NOFOLLOW" />
    <link type="text/css" href="css/elements.css" rel="stylesheet">
    <style type="text/css">
        #tfheader{
            background-color:#140029;
        }
        #tfnewsearch{
            float:right;
            padding:20px;
        }
        .tftextinput{
            margin: 0;
            padding: 5px 15px;
            font-family: Arial, Helvetica, sans-serif;
            font-size:14px;
            border:1px solid #0076a3; border-right:0px;
            border-top-left-radius: 5px 5px;
            border-bottom-left-radius: 5px 5px;
        }
        .tfbutton {
            margin: 0;
            padding: 5px 15px;
            font-family: Arial, Helvetica, sans-serif;
            font-size:14px;
            outline: none;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            color: #ffffff;
            border: solid 1px #FFFFFF; border-right:0px;
            background: #0095cd;
            background: -webkit-gradient(linear, left top, left bottom, from(#140029), to(#0078a5));
            background: -moz-linear-gradient(top,  #00adee,  #0078a5);
            border-top-right-radius: 5px 5px;
            border-bottom-right-radius: 5px 5px;
        }
        .tfbutton:hover {
            text-decoration: none;
            background: #007ead;
            background: -webkit-gradient(linear, left top, left bottom, from(#140029), to(#00678e));
            background: -moz-linear-gradient(top,  #0095cc,  #00678e);
        }
        .tfbutton::-moz-focus-inner {
            border: 0;
        }
        .tfclear{
            clear:both;
        }
    </style>
</head>
<body background="images/2.jpg" >

<?php

session_start();
include 'db.php';

$sql13 = "SELECT `filmovi`.`film_id` as `film_id`, `ime`, `godina`, `ocena` FROM `sekojfilm`, `filmovi` WHERE `sekojfilm`.`film_id` = `filmovi`.`film_id` AND `godina` = 2013 ORDER BY `ocena` DESC limit 10";
$sql14 = "SELECT `filmovi`.`film_id` as `film_id`, `ime`, `godina`, `ocena` FROM `sekojfilm`, `filmovi` WHERE `sekojfilm`.`film_id` = `filmovi`.`film_id` AND `godina` = 2014 ORDER BY `ocena` DESC limit 10";

?>

<div id="tfheader">
    <form id="tfnewsearch" method="get" action="index.php">
        <input type="text" class="tftextinput" name="search" size="21" maxlength="120">
        <input type="submit" value="Пребарувај" class="tfbutton">
    </form>
    <div class="tfclear"></div>
</div>

<center>
    <table valign="center" width="1200" border="0" 	background="images/2.jpg">
        <tr height="10"><td></td><td></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size="5" style="color:white">
                <div style="font-size: 18px;">
                    <?php
                    //$_SESSION['user_name'] = '';
                    $signedin = isset($_SESSION['signed_in']) ? $_SESSION['signed_in'] : '';
                    if($signedin == 'true')
                    {
                        echo 'Здраво, ' . $_SESSION['user_name'] . '. <a href="signout.php" style="color: white">Одјави се</a>';
                    }else{
                        echo '<a href="signin.php" style="color: white">најави се</a> или <a href="signup.php" style="color: white">регистрирај се</a>';
                    }
                    ?>
                </div>
        <tr height="200">
            <td colspan="3"><center> <b><font size="4" style="color:white"><img src="images/3.jpg"><br/>
                <!--<br/> Место за најдобрите филмови -->
            </font></b>
            </td></tr>
</center>
<tr><td width="100">
    <table width=100% border="0">
        <tr height="350"><td><img src="images/logo.png" width="210" height="280" border="0" alt="Logo"></td></tr>
        <tr height="350"><td>
            <ul style="list-style-type:disc"><font size="4" style="color:white"><br/><b>Топ 10 филмови во 2013</b><br/><br/>
            <?php
            $result13 = mysqli_query($db, $sql13);
    while($row = mysqli_fetch_assoc($result13)){
        echo '<li><b><a style="color:white" href="detali.php?id=' . $row['film_id'] . '">' . $row['ime'] . '</a></b></li>';
    }
            ?>
        </ul></td></tr><br/>

        <tr height="350"><td>

            <ul style="list-style-type:disc"><font size="4" style="color:white"><br/><b>Топ 10 филмови во 2014</b><br/><br/>
                <?php
                $result14 = mysqli_query($db, $sql14);
                while($row = mysqli_fetch_assoc($result14)){
                    echo '<li><b><a style="color:white" href="detali.php?id=' . $row['film_id'] . '">' . $row['ime'] . '</a></b></li>';
                }
                ?>
            </ul></td></tr>
        <tr height="350"><td><center><a href="http://www.atlantis.mk/"> <img src="images/apsolventska.jpg" width="230" height="300" border="0"></a></center></td></tr>


    </table>
</td>

    <td width="*">
        <table width=100% border="0">
            <tr>
                <td> <a href="index.php" style="color:white"><center><font size="5"><b> Почетна </b></font></center></td>
                <td> <a href="film.php?kategorija=akcija" style="color:white"><center><font size="5"><b> Акција </b></font></center></td>
                <td> <a href="film.php?kategorija=drama" style="color:white;"><center><font size="5"><b> Драма </b></font></center></td>
                <td> <a href="film.php?kategorija=komedija" style="color:white;"><center><font size="5"><b> Комедија </b></font></center></td>
                <td> <a href="film.php?kategorija=triler" style="color:white;"><center><font size="5"><b> Трилер </b></font></center></td>
                <td> <a href="film.php?kategorija=horor" style="color:white;"><center><font size="5"><b> Хорор </b></font></center></td>
            </tr>

