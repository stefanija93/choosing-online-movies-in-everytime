<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Stefi
 * Date: 1/17/15
 * Time: 2:00 PM
 * To change this template use File | Settings | File Templates.
 */
 
include'header.php';
include'db1.php';

if(isset($_GET['search'])){
    $search = $_GET['search'];
$sql_search = "SELECT *\n"
. "FROM filmovi\n"
. "WHERE ime LIKE '%$search%'";
    $stmt_search = $db->query($sql_search);
    if(!$stmt_search)
    {
        echo '<table width=100% border="0" style="margin-top: 80px;">';
        echo '<tr><td class="kategorija_pole">';
        echo '<div class="film_pole" style="color: white; font-size: 20px">Таков филм не е пронајден</div><div class="film_pole"></div>';
        echo '</td></tr>';
        echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
        echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
        echo '</table>';
    }
    else
    {
        $rowCount = $stmt_search->rowCount();
        $result = $stmt_search->fetchAll(PDO::FETCH_ASSOC);
        if($rowCount == 0)
        {
            echo '<table width=100% border="0" style="margin-top: 80px;">';
            echo '<tr><td class="kategorija_pole">';
            echo '<div class="film_pole" style="color: white; font-size: 20px">Таков филм не е пронајден</div><div class="film_pole"></div>';
            echo '</td></tr>';
            echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
            echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
            echo '</table>';
        }
        else {

            echo '<table width=100% border="0" style="margin-top: 80px;">';
            echo '<tr><td class="kategorija_pole">';
//            echo '<div class="film_pole">';
            foreach($result as $result_row){
                echo '<div class="film_pole">'.
                    '<a href="detali.php?id=' . $result_row['film_id'] . ' "><img src="' . $result_row['slika'] . '" width="250" height="400" border="0">'.
                    '<p><center><font size="4" style="color:white">' . $result_row['ime'] . '</font></center></a>'.
                    '</div>';
            }
            ?>

        <?php
            echo '</td></tr>';
            echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
            echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
            echo '</table>';
        }
    }
}else{

    $sql = "select film_id, ime, slika\n"
        . "from filmovi, kategorija\n"
        . "where kategorija.kategorija_id = filmovi.kategorija_id\n";

    $stmt =  $db->query($sql);
    if(!$stmt)
    {
        echo '<table width=100% border="0" style="margin-top: 80px;">';
        echo '<tr><td class="kategorija_pole">';
        echo '<div class="film_pole" style="color: white; font-size: 20px">Филмовите не можат да се прикажат во моментов. Обидете се подоцна.</div><div class="film_pole"></div>';
        echo '</td></tr>';
        echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
        echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
        echo '</table>';

    }
    else
    {
		$rowCount = $stmt->rowCount();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if($rowCount == 0)
        {
            echo '<table width=100% border="0" style="margin-top: 80px;">';
            echo '<tr><td class="kategorija_pole">';
            echo '<div class="film_pole" style="color: white; font-size: 20px">Нема внесено филмови во базата.</div><div class="film_pole"></div>';
            echo '</td></tr>';
            echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
            echo '<tr><td><div class="film_pole"><div class="film_pole"></td></tr>';
            echo '</table>';

        }
        else {
            $rand_films_array = array();
            echo '<table width=100% border="0" style="margin-top: 80px;">';
            echo '<tr><td class="kategorija_pole">';
            for($i = 0; $i < 6; $i++){
                $rand = rand(1, $rowCount);
                $sql1 = "select film_id, ime, slika\n"
                    . "from filmovi, kategorija\n"
                    . "where kategorija.kategorija_id = filmovi.kategorija_id and film_id = " . $rand . " limit 1";
                $stmt1 = $db->query($sql1);
                $result_row = $stmt1->fetch();
                echo '<div class="film_pole">'.
                    '<a href="detali.php?id=' . $result_row['film_id'] . ' "><img src="' . $result_row['slika'] . '" width="250" height="400" border="0">'.
                    '<p><center><font size="4" style="color:white">' . $result_row['ime'] . '</font></center></a>'.
                    '</div>';
            }
            ?>

        <?php
            echo '</td></tr></table>';
        }
    }
}

include 'footer.html';
?>